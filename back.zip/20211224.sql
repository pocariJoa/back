6.1 서브쿼리
  : SQL 문장안에 또 다른 SQL 문장을 서브쿼리라한다
  서브쿼리는 괄호() 로 묶어 사용
  서브쿼리가 포함된 쿼리문을 메인쿼리라 한다
  
  서브쿼리는 단일 행 또는 복수 행 비교 연산자와 함께 사용가능
  서브쿼리는 ORDER BY 를 사용하지 못함
  ORDER BY 는 메인 쿼리 문장의 마지막에 하나만 위치할 수 있음
  
  서브쿼리의 결과는 메인 쿼리의 조건으로 사용
  
  서브쿼리는 메인쿼리가 서브쿼리를 포함하는 종속적인 관계
  서브쿼리는 연산자 오른쪽에 사용
  여러번의 서브쿼리를 수행해야만 얻을 수 있는 결과를
  하나의 중첩된 SQL 문장으로 간편하게 결과를 얻을 수 있게 해줌
  
※ 서브쿼리 사용 이유
1. 알려지지 않은 기준을 이용한 검색을 하기 위해
- 테이블내에서 조건을 설정하기 어려워 다른 테이브렝서 조건을 가져와야 할 경우
  단일 SELECT 문으로 조건식을 만들기에는 조건이 복잡할때
  또는 완전히 다른 테이블에서 데이터값을 조회하여 메인 쿼리의 조건으로 사용하고자 할 경우
2. DB에 접근하는 속도를 향상 시킴

※ 서브쿼리가 사용 가능한곳
1. SELECT 절
2. FROM 절
3. WHERE 절 -- 제일 많이 사용되는 곳
4. HAVING 절
5. ORDER BY 절
6. INSERT 절의 VALUE 절
7. UPDATE 절의 SET절
  
※ 서브쿼리의 위치에 따른 명칭
1. SELECT 절에 사용하는 서브쿼리
  ○ 스칼라 서브쿼리, SQL 에서 단일값을 스칼라 값이라 함
  Scalar : (크기)하나, Vector : 크기와ㅣ 방형
  SELECT 문에 서브쿼리를 사용하여 하나의 컬럼처럼 사용하기 위한 목적(컬럼표현용도)

2. FROM 절에 사용하는 서브쿼리
  ○ 인라인뷰 서브쿼리
  SELECT 절의 결과를 FROM절에서 하나의 테이블처럼 사용(테이블 대체 용도)
  인라인뷰 서브쿼리에 ORDER BY 절은 올수 없음
  (출력 용도가 아닌 테이블처럼 사용하므로 굳이 정렬할 필요가 없음)
  인라인뷰 서브쿼리는 반드시 ALIAS 해야 함
  ALIAS 지정함으로써 하나의 컬럼명으로 사용함

3. WHERE 절에 사용하는 서브쿼리
  ○ 일반 서브쿼리 - 메인 쿼리 문안에 있는 또 다른 쿼리문(WHERE / HAVING 조건절에서 사용)
  ※ 서브쿼리의 SELECT 절에 결과를 하나의 변수 / 상수로 사용
  (조건절은 서브쿼리의 결과에 따라 달라짐  ▶ 단일 결과행, 다중결과행, 다중컬럼인지에 따라 달라짐
  보통 함수로 구한값과 비교할때, 다른곳에서 구한값과 비교할때
3.1 단일 결과행 서브쿼리 - 조건절에 사용하는 서브쿼리의 결과행이 단일행인 경우
  (조건절의 결과값을 기준으로 결과가 하나)
3.2 다중 결과행 서브쿼리 - 조건절에 사용하는 서브쿼리의 결과행이 여러행인 경우
  (조건절의 결과값을 기준으로 결과가 여러개)  
3.3 다중 컬럼 서브쿼리 - 조건절에 사용하는 서브쿼리의 결과컬럼이 여러컬럼인 경우
  (조건절의 결과값을 기준으로 컬럼이 여러개)

01. 급여가 우리회사 평균 급여보다 더 적은 급여를 받는 사원의
사번, 이름, 성, 급여 정보 조회
SELECT AVG(SALARY) --6461.831775700934579439252336448598130841
FROM  EMPLOYEES;

SELECT EMPLOYEE_ID, LAST_NAME, SALARY
FROM  EMPLOYEES
--WHERE AVG(SALARY)>SALARY;-- XXX WHERE 절에서는 그룹함수 사용불가
--HAVING AVG(SALARY)>SALARY; -- XXX 반드시 GROUP BY 아래서 사용
WHERE SALARY <(SELECT AVG(SALARY) FROM EMPLOYEES);
단일 결과행 서브쿼리에서 용하는 연산자 : =, != , <>, <, >, <=, >=

02. 급여가 우리회사 평균 급여보다 더 많게 받는 사원의
사번, 성, 업무코드, 급여 조회
우리회사평균급여
SELECT AVG(SALARY)
FROM EMPLOYEES;

SELECT EMPLOYEE_ID, LAST_NAME, JOB_ID, SALARY
FROM EMPLOYEES
--WHERE SALARY > (우리회사평균급여)
WHERE SALARY > (SELECT AVG(SALARY)
FROM EMPLOYEES);

03. 우리회사에서 최대급여를 받는 사원의
사번, 성, 명, 급여 조회
SELECT MAX(SALARY)
FROM EMPLOYEES;

SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, SALARY
FROM EMPLOYEES
WHERE SALARY = (SELECT MAX(SALARY)
FROM EMPLOYEES);
  
04. 150번 사원보다 더 많은 급여를 받는 사원들의 
사번, 성, 부서코드, 업무코드 급여 조회
SELECT SALARY FROM EMPLOYEES WHERE EMPLOYEE_ID = 150;

SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, JOB_ID ,SALARY
FROM EMPLOYEES 
WHERE SALARY > (SELECT SALARY FROM EMPLOYEES WHERE EMPLOYEE_ID = 150);
  
05. 월급여가 가장 많은 사원의
사번, 이름, 성, 업무제목 조회
SELECT MAX(SALARY)
FROM EMPLOYEES;

SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, SALARY
FROM EMPLOYEES
WHERE SALARY = (SELECT MAX(SALARY)
FROM EMPLOYEES);

06. 사원들의 급여가 우리회사 평균급여 이상 최고급여 이하에 해당하는 사원들의
사번, 성, 급여 조회
SELECT AVG(SALARY) FROM EMPLOYEES;
SELECT MAX(SALARY) FROM EMPLOYEES;

SELECT EMPLOYEE_ID, LAST_NAME, SALARY
FROM EMPLOYEES
WHERE SALARY BETWEEN (SELECT AVG(SALARY) FROM EMPLOYEES) AND (SELECT MAX(SALARY) FROM EMPLOYEES);

2. 다중결과행 서브쿼리
  : 조건절에 사용하는 서브쿼리의 결과행이 여러행인 경우,
  : 연산자 - IN, NOT IN
    비교의 대상이 2개 이상은 대소비교 불가, 그래서 IN 연산자 사용
    서브쿼리의 결과행이 여러행이면, = , <, >, >=, <= 와 같으 ㄴ연산자는 사용불가
    WHERE 절에서는 그룹함수 사용 불가
    WHERE 절이 아닌 서브 쿼리에는 그룹함수 사용가능
    
01. 부서의 위치코드가  1700인 사원들의 
사번, 성, 부서코드, 업무코드 조회
SELECT E.EMPLOYEE_ID, E.LAST_NAME, D.DEPARTMENT_ID, E.JOB_ID
FROM EMPLOYEES E, DEPARTMENTS D
WHERE E.DEPARTMENT_ID = D.DEPARTMENT_ID
AND D.LOCATION_ID = 1700 ;

01. 부서의 위치코드가  1700인 부서에 속한 사원들의 
사번, 성, 부서코드, 업무코드 조회
SELECT DEPARTMENT_ID
FROM DEPARTMENTS
WHERE LOCATION_ID = 1700 ;

SELECT E.EMPLOYEE_ID, E.LAST_NAME, E.DEPARTMENT_ID, E.JOB_ID
FROM EMPLOYEES E
WHERE E.DEPARTMENT_ID IN (SELECT DEPARTMENT_ID
                          FROM DEPARTMENTS
                          WHERE LOCATION_ID = 1700 );
02. 우리회사에서 MGR 업무에 종사하는 사원들과 같은 부서에 속한 사원들의 
사번 , 성, 업무코드, 부서코드 조회
SELECT DEPARTMENT_ID
FROM EMPLOYEES
WHERE UPPER(JOB_ID) LIKE '%MGR%';

SELECT EMPLOYEE_ID, LAST_NAME, JOB_ID, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID IN(SELECT DEPARTMENT_ID
                       FROM EMPLOYEES
                       WHERE UPPER(JOB_ID) LIKE '%MGR%');

























  
  