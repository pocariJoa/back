-- HR 유저에 관리되는 테이블 확인
SELECT table_name
from user_tables;

REGIONS      : 대륙정보
COUNTRIES    : 국가정보
LOCATIONS    : 위치정보
DEPARTMENTS  : 부서정보
JOBS         : 업무정보
EMPLOYEES    : 사원정보
JOB_HISTORY  : 업무이력정보

2.1 데이터 조회
- DESC(DESCRIBE) : 테이블의 컬럼명, 데이터형, 길이, NULL 허용ㅇ 유무 등 특정 테이블의
정보를 제공
DESCRIBE 테이블명 = DESC 테이블명

DESC employees; --실행, CTRL + ENTER, F5

이름             널?       유형           
-------------- -------- ------------ 
EMPLOYEE_ID    NOT NULL NUMBER(6)    : 사번
FIRST_NAME              VARCHAR2(20) : 이름
LAST_NAME      NOT NULL VARCHAR2(25) : 성
EMAIL          NOT NULL VARCHAR2(25) : 이메일
PHONE_NUMBER            VARCHAR2(20) : 전화번호
HIRE_DATE      NOT NULL DATE         : 입사일
JOB_ID         NOT NULL VARCHAR2(10) : 업무코드
SALARY                  NUMBER(8,2)  : 급여
COMMISSION_PCT          NUMBER(2,2)  : 상여율
MANAGER_ID              NUMBER(6)    : 매니저코드
DEPARTMENT_ID           NUMBER(4)    : 부서코드

○ SELECT : 테이블에 저장된 데이터를 조회하기위한 명령어, SQL문 중에서 가장 많이 사용
           SELECT 문에는 반드시  FROM 키워드가 따라와야 함
○ WHERE  : SELECT 문에서 마지막에 쓸수 있는데 원하는 레코드만 검색하고자 할때 사용
           조건절의 구성은 컬럼, 연산자, 비교 대상값이 올 수 있다

SELECT 안의
*     : 모든것
컬럼명 : 특정컬럼명

SELECT *
FROM 테이블명;

SELECT 컬럼명1, 컬럼명2...
FROM 테이블명;

사원테이블에서 모든 컬럼 조회
SELECT * 
FROM EMPLOYEES;

사원테이블에서 사번, 이름, 성 조회
SELECT EMPLOYEE_ID,FIRST_NAME,LAST_NAME
FROM EMPLOYEES;

사원테이블에서 사번, 이름, 성, 부서코드, 입사일자, 업무코드, 급여 조회
SELECT EMPLOYEE_ID,FIRST_NAME,LAST_NAME,DEPARTMENT_ID,HIRE_DATE,JOB_ID,SALARY
FROM EMPLOYEES;

2.2 WHERE 조건절 : 특정 조건에 맞는 데이터 행을 조회하고자 할 때.
                  ※ where 절에서는 ALIAS 사용불가
                  
SELECT 컬럼명...
FROM 테이블명
WHERE 조건

○ WHERE 절에서 사용가능한 연산자
1. 산술연산자 : +, -, *, / : SELECT 절과 WHERE 절에서 사용가능
2. 문자열연결연산자 : || : SELECT 절과 WHERE 절에서 사용가능
3. 비교 연산자 : =(같다), !=, ^=, <> (같지않다), >(초과), <(미만) , >=(이상), <=(이하
               : DB에서는 같다는 '==' 가 아니고, '='하나만 사용함
               : 문자나 날짜는 반드시 홀따옴표('')로 묶어서 사용 ALIAS 만 쌍따옴표("")로 묶음
4. 논리조건연산자 : AND, OR, NOT
5. 범위조건연산자 : BETWEEN ~ AND~
6. IN 조건 연산자 OR 연산자와 동일한 기능을 수행
7. LIKE 조건연산자 : 특정 단어를 포함하는 값을 조회
8. NULL 조건처리연산자 : 데이터값이 없는 형태의 표현 -> NULL : 비교불가, 산술연산불가
                       : 값 = NULL,  값 != NULL <- 틀린표현
                       : 값 IS NULL,  값 IS NOT NULL <- 옳은표현
                       
2.3 연산자
1. 산술연산자
01. 80번 부서의 사번, 성, 급여, 연봉 조회
SELECT EMPLOYEE_ID,LAST_NAME,SALARY,SALARY*12 연봉
FROM EMPLOYEES
WHERE DEPARTMENT_ID =80;

SELECT 절에서 다음과 같을때는 ALIAS(별명, 별칭, 애칭)를 습관적으로 지정하기
1. 컬럼의 표현이 지나치게 긴경우
2. 컬럼의 표현이 연산자/함수가 사용된 경우

SELECT EMPLOYEE_ID,FIRST_NAME, LAST_NAME, DEPARTMENT_ID, SALARY, SALARY*12 연봉
FROM EMPLOYEES
WHERE SALARY*12>=150000;

2. 문자열 연결 연산자  : ||
01. 사번이 101번인 사원의 사번, 성명을 조회
성명은 이름과 성을 합해서 사용한다
SELECT EMPLOYEE_ID, FIRST_NAME || ' ' || LAST_NAME 성명
FROM EMPLOYEES
WHERE EMPLOYEE_ID = 101;

02. 성명이 StevenKing 인 사원의
사번,성명, 업무코드 급여, 부서코드 조회
select EMPLOYEE_ID, FIRST_NAME || ' ' || LAST_NAME 성명,JOB_ID, DEPARTMENT_ID
from EMPLOYEES
where FIRST_NAME || LAST_NAME = 'StevenKing';

3. 비교 연산자
01. 급여가 3000 이하인  사원의
사번, 성, 급여, 부서코드, 업무코드 조회
select EMPLOYEE_ID,LAST_NAME, SALARY, DEPARTMENT_ID
from EMPLOYEES
where salary <= 3000;

02. 부서코드가 90인 부서에 속한 사원들의
사번, 이름, 성, 부서코드, 업무코드 조회
select EMPLOYEE_ID,LAST_NAME, SALARY, DEPARTMENT_ID,JOB_ID
from  EMPLOYEES
where DEPARTMENT_ID =90;
-----------------------------------
오늘 날짜 조회
select SYSDATE today -- 날짜는 '/'로 구분
from dual;
날짜포맷을 사용하여 사용자가 원하는 형태의 문자로 바꿔 변화
:TO_CHAR
SELECT  TO_CHAR(SYSDATE, 'YYYY/MM/DD') TODAY 
FROM DUAL;
SELECT  TO_CHAR(SYSDATE, 'YYYY-MM-DD') TODAY 
FROM DUAL;
SELECT  TO_CHAR(SYSDATE, 'YYYY.MM.DD') TODAY 
FROM DUAL;
SELECT TO_CHAR(SYSDATE,'YYYY/MONTH/DAY') TODAY FROM DUAL;
SELECT TO_CHAR(SYSDATE,'YYYY/MON/DY') TODAY FROM DUAL;
SELECT TO_CHAR(SYSDATE,'YYYY/MM/DD HH:MI:SS') TODAY FROM DUAL;
SELECT TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS') TODAY FROM DUAL;

03. 입사일이 2004년 1월 1일 이전 (즉, 2003년까지)인 사원의
사번, 성, 입사일자 조회
SELECT EMPLOYEE_ID,LAST_NAME,HIRE_DATE
FROM EMPLOYEES
--WHERE HIRE_DATE <= '2003-12-31';
--WHERE HIRE_DATE <= '2004-01-01';
WHERE HIRE_DATE <= TO_DATE('2003-12-31');

4. 논리연산자
4.1 AND 연산자 : 조건이 모두 TRUE 일때만 TRUE를 반환

01. 30번 부서 사원중 급여가 10000이하인 ㅅ가원의
사번, 성명, 급여, 부서코드 조회
SELECT EMPLOYEE_ID, FIRST_NAME|| ' ' ||LAST_NAME 성명, SALARY, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID=30
AND  SALARY <= 10000;

02. 30번 부서에서 급여가 10000이하 이면서 2005년 이전(2004년까지에 입사한 사원들의
사번, 성명, 급여, 부서코드 입사일자 조회
성명은 이름과 성을 합하여 사용하고 NAME으로 ALIAS 한다
SELECT EMPLOYEE_ID, FIRST_NAME|| ' ' ||LAST_NAME 성명, SALARY, DEPARTMENT_ID,HIRE_DATE
FROM EMPLOYEES
WHERE DEPARTMENT_ID=30
AND SALARY <= 10000
AND HIRE_DATE <= TO_DATE('2004-12-31');

03. 부서코드가 10이상 30이하인 사원들의
사번, 성명, 부서코드 조회
성명은 이름과 성을 합하여 사용하고 name으로 alias한다

SELECT EMPLOYEE_ID, FIRST_NAME|| ' ' ||LAST_NAME 성명, SALARY, DEPARTMENT_ID,HIRE_DATE
FROM EMPLOYEES
WHERE DEPARTMENT_ID<=30
AND DEPARTMENT_ID>=10;

04. 급여가 10000이상 15000이하인 사원들의
사번, 성명, 급여 업무코드 조회
SELECT EMPLOYEE_ID, FIRST_NAME|| ' ' ||LAST_NAME 성명, DEPARTMENT_ID,HIRE_DATE
FROM EMPLOYEES
WHERE SALARY>=10000
AND SALARY<=15000;

4.2 or 연산자 : 조건중 하나만 TRUE이면 TRUE를 반환
01. 30번 부서나 40번 부서에 속한 사원들의
사번, 성명, 급여, 부서코드 조회
SELECT EMPLOYEE_ID,FIRST_NAME|| ' ' ||LAST_NAME 성명
FROM EMPLOYEES
WHERE DEPARTMENT_ID<=30
OR DEPARTMENT_ID>=10;
02.부서코드가 10,20,30인 부서에 속한 사원드르이
사번, 성명, 부서코드, 업무코드 조회
SELECT EMPLOYEE_ID,FIRST_NAME|| ' ' ||LAST_NAME 성명
FROM EMPLOYEES
WHERE DEPARTMENT_ID=30
OR  DEPARTMENT_ID=20
OR  DEPARTMENT_ID=10
4.3 AND연산자와 OR연산자를 혼합하여 문장을 작성한다
01.  30번 부서의 급여가 10000 미만ㅇ인 사원과
     60번 부서의 급여가 5000 이상인 사원의
     성명, 급여, 부서코드 정보를 조회한다
SELECT EMPLOYEE_ID,FIRST_NAME|| ' ' ||LAST_NAME 성명
FROM EMPLOYEES
WHERE (DEPARTMENT_ID=30 AND  SALARY<10000)  --가독성 때문에 괄호로 묶어주느게 좋다
OR  (DEPARTMENT_ID=60 AND  SALARY>5000);

5.범위 조건 연산자 : BETWEEN AND
BETWEEN 시작값 AND 마지막값 : 시작값 이상 마지막값 이하
숫자, 문자, 날짜, 모두 사용가능

SELECT EMPLOYEE_ID,FIRST_NAME|| ' ' ||LAST_NAME 성명
FROM EMPLOYEES
WHERE EMPLOYEE_ID BETWEEN 110 and 120;

6. IN 조건연산자
:여러개의 값 중 일치하는 값이 있는지 비교할때는 IN(값1, 값2, 값3,)의 형태로비교하는
값의 목록을 나열한다
동일한 컬럼 표현에 대해 동등비교한 형태의 조건식을 OR로 나열한 형태
컬럼표현 IN(동등비교할 데이터값 목록)
컬럼표현 NOT IN(동등비교할 데이터값 목록)
NOT 컬럼표현 IN(동등비교할 데이터값 목록)

01. 30번 부서또는 60번 부서 도는 90번 부서의
사번, 성, 급여, 부서코드 조회
SELECT  EMPLOYEE_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID =30
OR DEPARTMENT_ID = 60
OR DEPARTMENT_ID = 90;

SELECT  EMPLOYEE_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID IN (30,60,90);

7. 검색에 해당하는 연산자 : 필드명 LIKE 조건연산자(포함하는)
                          : 필드명 NOT LIKE 조건연산자(포함하지않는)
컬럼값을 통해 특정 패턴에 속하는 값을 조회하고자 하는 경우 like 연산를 사용한다
% : 모든것
_ : 한글자

성명 = '홍길동'
성명 LIKE '홍%'  : 홍으로 시작하는
성명 LIKE '%홍'  : 홍으로 끝나는
성명 LIKE '%홍%' : 홍을 포함하는

01. 이름이 k로 시작하는 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name like 'K%';

02. 이름이 s로 끄탄는 이름을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name like '%s';

03. 성에 소문자 z가 포함된 성을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name like '%z%';

04. 성에 대소문자 무관 z가 포함된 성을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name like '%Z%' 
or  last_name like'%z%';

04. 성명에 대소문자 무관 z가 포함된 성을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name || FIRST_NAME  like '%Z%' 
or  last_name || FIRST_NAME like'%z%';

05. 성에 소문자 z가 앞에서 2번째에 위치해있는 성을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name  like '____z%' 
06. 성에 소문자 z가 뒤에서 5번째에 위치해있는 성을 가진 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where last_name  like '%z____' 
07. 전화번호가 6으로 시작하지 않은 사원의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE
from EMPLOYEES
where PHONE_NUMBER not LIKE '6%';
08. 입사일자가 12월에 입사한 사원들의
사번, 이름, 성, 입사일자 조회
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, HIRE_DATE 
from EMPLOYEES
where HIRE_DATE LIKE '%/12/%';








