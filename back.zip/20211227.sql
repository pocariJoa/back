03. 각 부서의 최소급여가 40번 부서의 최소급여보다 더 많이 받는 부서의
부서코드, 최소급여 조회
일반쿼리


서브쿼리
SELECT MIN(SALARY)
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 40;

SELECT DEPARTMENT_ID, MIN(SALARY) 최소급여
FROM EMPLOYEES
HAVING MIN(SALARY) > (SELECT MIN(SALARY)
                FROM EMPLOYEES
                WHERE DEPARTMENT_ID = 40)
GROUP BY DEPARTMENT_ID; 

04. 근무지의 국가코드가 uk(즉 country_id가 uk) 인 위치에 있는
부서코드, 위치코드, 부서명 조회
일반쿼리

서브쿼리
SELECT LOCATION_ID
FROM  COUNTRIES
WHERE UPPER(COUNTRY_ID) LIKE  '%UK%';

SELECT D.DEPARTMENT_ID, D.LOCATION_ID, D.DEPARTMENT_NAME
FROM DEPARTMENTS D
WHERE  LOCATION_ID IN (SELECT LOCATION_ID
FROM  LOCATIONS
WHERE UPPER(COUNTRY_ID) LIKE  '%UK%');

------------------------------------------------------------------------------
성에 대소문자 무관하게 Z가 포함된 성을 가진 사원들의
사번, 성, 부서코드, 업무코드 조회
SELECT LAST_NAME, DEPARTMENT_ID, JOB_ID
FROM EMPLOYEES
WHERE UPPER(LAST_NAME) LIKE'%Z%';
-----------------------------------------------------------------------------
성에 대소문자 무관하게 Z가 포함된 성을 가진 사원들과 같은 부서에 속한
사번, 성, 부서코드 업무코드 조회
SELECT E.EMPLOYEE_ID, E.LAST_NAME, E.DEPARTMENT_ID, E.JOB_ID
FROM EMPLOYEES E
WHERE E.DEPARTMENT_ID IN (SELECT DEPARTMENT_ID
                        FROM EMPLOYEES
                        WHERE UPPER(LAST_NAME) LIKE'%Z%');

06. 60번 부서원들과 같은 급여를 받는  사원들의 
사번, 성, 급여, 부서코드 조회 : 부서, 급여 포함된 테이블 : EMPLOYEES
SELECT SALARY
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 60;

SELECT EMPLOYEE_ID, LAST_NAME, SALARY, DEPARTMENT_ID
FROM EMPLOYEES
WHERE SALARY IN (SELECT SALARY
                 FROM EMPLOYEES
                 WHERE DEPARTMENT_ID = 60);

07. 60번 부서에 속하지 않으면서
60번 부서원들과 같은 급여를 받는  사원들의 
사번, 성, 급여, 부서코드 조회 : 부서, 급여 포함된 테이블 : EMPLOYEES
SELECT SALARY
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 60;

SELECT EMPLOYEE_ID, LAST_NAME, SALARY, DEPARTMENT_ID
FROM EMPLOYEES
WHERE SALARY IN (SELECT SALARY
                 FROM EMPLOYEES
                 WHERE DEPARTMENT_ID = 60 );

08. 부서명이 Marketing 이거나 IT에 속한 부서의 사원들의
사번, 성, 부서코드 조회
SELECT DEPARTMENT_ID
FROM DEPARTMENTS
WHERE UPPER(DEPARTMENT_NAME) IN('MARKETING','IT');

SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID IN (SELECT DEPARTMENT_ID
                        FROM DEPARTMENTS
                        WHERE UPPER(DEPARTMENT_NAME) IN('MARKETING','IT'));
                        
09. 매니저가 없는 사원이 매니저로 있는
부서코드, 부서명, 매니저 아이디조회
SELECT EMPLOYEE_ID
FROM EMPLOYEES
WHERE MANAGER_ID IS NULL ;

SELECT DISTINCT E.DEPARTMENT_ID,d.department_name , E.MANAGER_ID
FROM EMPLOYEES E, DEPARTMENTS D 
WHERE E.DEPARTMENT_ID = D.DEPARTMENT_ID(+)
AND E.MANAGER_ID IN (SELECT EMPLOYEE_ID
                     FROM EMPLOYEES
                     WHERE MANAGER_ID IS NULL )
ORDER BY 1;

3. 다중컬럼 서브쿼리 : 서브쿼리의 결과 컬럼이 여러개인 경우,
조건의 결과값을 기준으로 컬럼이 여러개
다중컬럼을 pair  형태로 비교한다
01. 부서벼로 가장많은 급여를 받는 사원의
부서코드, 최대급여 조회
SELECT DEPARTMENT_ID, MAX(SALARY)
FROM EMPLOYEES
GROUP BY  DEPARTMENT_ID
ORDER BY 1;

02. 부서별로 가장 많은 급여를 받는 사원의
부서코드, 최대급여, 이름 조회
SELECT E.DEPARTMENT_ID, E.SALARY, E.FIRST_NAME
FROM EMPLOYEES E
WHERE (nvl(E.DEPARTMENT_ID,0), E.SALARY) IN (SELECT nvl(DEPARTMENT_ID,0), MAX(SALARY) max_sal
--                                            ↑ 부서별로 최대급여를 급여로 전달
                                             FROM EMPLOYEES
                                             GROUP BY  DEPARTMENT_ID)
ORDER BY 1;

03. 부서별로 가장 많은 급여를 받는 사원의
사번, 성명, 부서코드, 최대급여, 업무코드 조회
SELECT DEPARTMENT_ID, MAX(SALARY)
FROM EMPLOYEES
GROUP BY  DEPARTMENT_ID
ORDER BY 1;

SELECT E.EMPLOYEE_ID, E.FIRST_NAME|| ' '|| E.LAST_NAME 이름, E.DEPARTMENT_ID, E.SALARY, E.JOB_ID
FROM  EMPLOYEES E
WHERE (nvl(E.DEPARTMENT_ID,0), E.SALARY) IN (SELECT nvl(DEPARTMENT_ID,0), MAX(SALARY) max_sal
--                                            ↑ 부서별로 최대급여를 급여로 전달
                                             FROM EMPLOYEES
                                             GROUP BY  DEPARTMENT_ID)
ORDER BY 3;

04. 각부서별로 가장 최근에 입사한 사원들의
사번, 성, 부서코드, 가장 최근 입사일자 조호
SELECT DEPARTMENT_ID, MAX(HIRE_DATE)
FROM EMPLOYEES
GROUP BY  DEPARTMENT_ID
ORDER BY 1;

SELECT E.EMPLOYEE_ID, E.FIRST_NAME|| ' '|| E.LAST_NAME 이름, E.DEPARTMENT_ID, E.HIRE_DATE
FROM  EMPLOYEES E
WHERE (nvl(E.DEPARTMENT_ID,0), E.HIRE_DATE) IN (SELECT nvl(DEPARTMENT_ID,0), MAX(HIRE_DATE)
                                             FROM EMPLOYEES
                                             GROUP BY  DEPARTMENT_ID)
ORDER BY 3;

4. 상호연관 서브 쿼리 : 메인 쿼리의 컬럼이 서브쿼리의 조건절에 사용되는 형태
- 메인쿼리의 값을 서브쿼리에 주고, 서브쿼리의 결과값을 받아서 메인쿼리로 반환해서
  수행하는 쿼리
- 메인쿼리의 컬럼이 서브쿼리의 조건절에 사용되어 메인쿼리에 독립적이지 않은 형식
- 메인쿼리 테이블과 서브쿼리 테이블간의 조인 조건이 사용됨
- 메인쿼리와 서브쿼리가 계속 정보를 주고 받는다는 의미
- 메인 쿼리의 컬럼이 서브쿼리의 조건절에 사용되는
  상호연과 서브쿼리의 형태로 사용된다.(WHERE 절에서 사용)
- 스칼라 서브쿼리에서 다룰 예정

5. 스칼라 서브쿼리 : SELECT 절에서 사용, 단일결과행, 단일컬럼만 조회가능
- 단순한 그룹함수의 결과를 SELECT 절에서 조회하고자 할 경우
- SELECT 절에서 서브쿼리를 사용하여 하나의 컬럼처럼 사용하기 위한 목적(컬럼 표현 용도)
- 코드성 데이터를 조회하고자 할 때
- 조인 조건식이 필요할때는 스칼라 서브쿼리 안에서 WHERE 조건식 사용




1) 단순한 그룹함수의 결과를 SELECT 절에서 조회하고자 할 경우
01. 각 사원의 급여수준을 파악하고자 한다.
모든 사원의  사번, 성, 급여, 회사평균 급여, 회사최대 급여 조회
SELECT EMPLOYEE_ID, LAST_NAME, SALARY , 
( SELECT ROUND(AVG(SALARY),2)FROM  EMPLOYEES ) 평균
, ( SELECT MAX(SALARY)FROM  EMPLOYEES ) 최대급여
FROM EMPLOYEES
GROUP BY EMPLOYEE_ID, LAST_NAME, SALARY;

SELECT ROUND(AVG(SALARY),2)
FROM  EMPLOYEES;

2) 코드성 테이블에서 코드명(즉, 데이터 컬럼명)을 SELECT 절에서 조회하고자 할 경우
: 상호연관서브쿼리. OUTER JOIN 한것처럼

01. 모든 사원의 사번, 성, 부서코드 , 부서명 조회
SELECT E.EMPLOYEE_ID, E.LAST_NAME, E.DEPARTMENT_ID, D.DEPARTMENT_NAME
FROM DEPARTMENTS D, EMPLOYEES E
WHERE E.DEPARTMENT_ID = D.DEPARTMENT_ID(+)
ORDER BY 1;

상호연관서브쿼리 : 메인쿼리의 컬럼이 서브쿼리의 조건절에 사용되는 형태
SELECT E.EMPLOYEE_ID, E.LAST_NAME, E.DEPARTMENT_ID,
          ( SELECT D.DEPARTMENT_NAME
            FROM DEPARTMENTS D
            WHERE D.DEPARTMENT_ID(+) = E.DEPARTMENT_ID) DEPARTMENT_ID
FROM EMPLOYEES E;

02. 모든 사원의 사번, 성, 부서코드, 업무코드, 업무제목 조회
일반쿼리
SELECT E.EMPLOYEE_ID, E.LAST_NAME, E.DEPARTMENT_ID, J.JOB_ID, J.JOB_TITLE
FROM  EMPLOYEES E, JOBS J
WHERE E.JOB_ID = J.JOB_ID;























