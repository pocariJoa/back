CREATE  TABLE emp AS
  SELECT  employee_id id, first_name, last_name, hire_date, 
          job_id, department_id dept_id
  FROM    employees
  WHERE   1 = 2; --엉터리조건

DESC emp;

이름         널?       유형           
---------- -------- ------------ 
ID                  NUMBER(6)    
FIRST_NAME          VARCHAR2(20) 
LAST_NAME  NOT NULL VARCHAR2(25) 
HIRE_DATE  NOT NULL DATE         
JOB_ID     NOT NULL VARCHAR2(10) 
DEPT_ID             NUMBER(4)

employees 테이블의 10번, 20번 부서원들의 정보를 복사하여
emp테이블에 데이터행을 삽입저장한다.

SELECT  employee_id, first_name, last_name, hire_date, job_id, department_id
FROM    employees
WHERE   department_id IN (10, 20);

INSERT INTO emp
  SELECT  employee_id, first_name, last_name, hire_date, job_id, department_id
  FROM    employees
  WHERE   department_id IN (10, 20);
  
SELECT  *
FROM    emp;

2. 변경저장 : UPDATE --반드시 조건 기술
UPDATE  테이블명
SET     컬럼명1 = 데이터값1, 컬럼명2 = 데이터값2, ....
WHERE   조건절;

01. emp테이블의 id가 202 인 사원의 dept_id 를 30, job_id를 programmer 로 변경저장
UPDATE  emp
SET     dept_id = 30, job_id = 'programmer'
WHERE   id = 202; --반드시 조건절 기술

SELECT  *
FROM    emp;

02. emp테이블에서 id가 202 인 사원의 job_id 를 PU_CLERK 로 변경저장
UPDATE  emp
SET     job_id = 'PU_CLERK'
WHERE   id = 202;

SELECT  *
FROM    emp;

03. emp테이블에서 id가 202 인 사원의 dept_id 를 NULL로 변경
UPDATE  emp
SET     dept_id = ''
WHERE   id = 202;

SELECT  *
FROM    emp;

04. 서브쿼리로 데이터 행 변경
emp 테이블에서 부서배치 받지 않은 사원들의 부서코드를
employees 테이블의 job_id가 'AD_PRES' 인 사원의 부서코드로 변경

SELECT  department_id --90
FROM    employees
WHERE   job_id = 'AD_PRES';

SELECT  *
FROM    emp
WHERE   dept_id IS NULL;

변경 저장하기
UPDATE  emp
SET     dept_id = ( SELECT  department_id 
                    FROM    employees 
                    WHERE   job_id = 'AD_PRES' )
WHERE   dept_id IS NULL;  

SELECT  *
FROM    emp;

COMMIT; --작업확정

SELECT  *
FROM    employees;

05. employees 테이블의
301번 사원의 salary 를 4000, first_name 을 우치, last_name 전 으로 변경저장

UPDATE  employees
SET     salary = 4000, first_name = '우치', last_name = '전'
WHERE   employee_id = 301;

SELECT  *
FROM    employees
WHERE   employee_id = 301;

06. employees 테이블의 
300번 부서에 속한 사원들의 salary 를 5000으로 변경저장

UPDATE  employees
SET     salary = 5000
WHERE   department_id = 300;

SELECT  *
FROM    employees
WHERE   department_id = 300;

07. employees 테이블에 새로운 사원정보 삽입저장
300으로 사번 지정하고, 급여는 60번부서의 평균 급여
employee_id, first_name, last_name, email, hire_date, job_id, salary
300, 길동, 홍, hong@naver.com, 오늘날짜, IT_PROG, 60번 부서의 평균

INSERT INTO employees(employee_id, first_name, last_name, email, hire_date, job_id, salary)
VALUES (300, '길동', '홍', 'hong@naver.com', SYSDATE, 'IT_PROG', 
        ( SELECT  ROUND(AVG(salary))
          FROM    employees
          WHERE   department_id = 60 ) );

SELECT  *
FROM    employees
WHERE   employee_id = 300;

08. 300번 사원의 급여를 우리회사 최고급여, 전화번호는 062.1111.1111 로 변경 저장
UPDATE  employees 
SET     salary = ( SELECT MAX(salary) FROM  employees ), phone_number = '062-1111.1111'
WHERE   employee_id = 300;

SELECT  *
FROM    employees
WHERE   employee_id = 300;

실습
01. emp 테이블의 200번 사원에 대해
employees 테이블의 60번 부서원 중 가장 최근에 입사한 사원의 입사일자로 변경
UPDATE  emp
SET     hire_date = ( SELECT  MAX(hire_date)
                      FROM    employees
                      WHERE   department_id = 60 )
WHERE   id = 200;

SELECT  *
FROM    emp
WHERE   id = 200;

02. emp 테이블의 202 번 사원의 입사일자를
오늘로부터 6개월 전의 날짜로 변경
UPDATE  emp
--SET     hire_date = ( SELECT ADD_MONTHS(SYSDATE, -6) FROM dual )
SET     hire_date = ADD_MONTHS(SYSDATE, -6)
WHERE   id = 202;

SELECT  *
FROM    emp
WHERE   id = 202;

COMMIT; 

3. 데이터 행 삭제 : DELETE --반드시 조건 기술, ROLLBACK 가능

DELETE  FROM  테이블명
WHERE   조건절

01. employees 테이블에서 300번 사원코드를 삭제하자
SELECT  *
FROM    employees
WHERE   employee_id = 300;

DELETE  FROM  employees
WHERE   employee_id = 300;

SELECT  *
FROM    employees
ORDER BY employee_id DESC;

02. departments 테이블에서 300번 부서를 삭제하자.
SELECT  *
FROM    departments
ORDER BY department_id DESC;

DELETE  FROM departments
WHERE   department_id = 300; --자식 레코드가 발견되었습니다

그래서, employees 테이블에서 자식 레코드인 300번 부서를 삭제하자
DELETE  FROM  employees
WHERE   department_id = 300;

그리고 나서, departments 테이블의 300번 부서를 삭제하자
DELETE  FROM  departments
WHERE   department_id = 300;

03. emp 테이블의 20번 부서원들의 정보를 삭제하자
SELECT  *
FROM    emp
WHERE   dept_id = 20;

DELETE  FROM  emp
WHERE   dept_id = 20;

COMMIT;

9장. DDL(Data Definition Language) --AUTO COMMIT;
CREATE, --테이블 생성
ALTER,  --테이블 구조변경
DROP,   --테이블 삭제
TRUNCATE, --테이블 내용 삭제(구조만 남기고)
RENAME  --테이블 이름 변경

1. 테이블 생성 -- CREATE
CREATE TABLE 테이블명 (
  컬럼명1  데이터타입1,
  컬럼명2  데이터타입2,
  ...
);

* 데이터 타입 : 문자, 숫자, 날짜
- 문자 : CHAR, VARCHAR2
    CHAR(n) - 고정문자, 지정된 크기만큼 메모리를 확보
      CHAR(10)  - 저장시 abcd 라는 문자를 저장 ☞ abcd______(총 10바이트로 저장)
                - 메모리를 10바이트 확보한 후 저장
    VARCHAR(10) - 가변문자 : 데이터를 저장할때 메모리 확보, 최대 4000바이트까지
      VARCHAR2(30) - 저장시 abcd 라는 문자를 저장 ☞ abcd(4바이트만 저장)

- 숫자 : NUMBER
    NUMBER(n) - 정수데이터
      NUMBER(8) - 99999999 까지
    NUMBER(n, p) - 부동소숫점 데이터, 정수부 : n-p, 소수부 : p
      NUMBER(8,2) - 정수부는 8-2 : 6, 소수부 : 2
      NUMBER(2,2) - 정수부는 2-2 : 0, 소수부 : 2
      
- 날짜 : DATE

CREATE  TABLE temp (
  id    NUMBER(4)       PRIMARY KEY,
  name  VARCHAR2(30)
);
    
01. temp 테이블에 데이터 삽입 저장
INSERT INTO temp  VALUES(100,'홍길동');
INSERT INTO temp  VALUES(101,'이순신');

COMMIT;

02. temp 테이블에서 id 가 101인 name 을 홍명보로 변경저장
SELECT  *
FROM    temp;

UPDATE  temp
SET     name = '홍명보'
WHERE   id= 101;

SELECT  *
FROM    temp;

2. 데이터 구조 변경 --ALTER
1) 컬럼 추가 -- ADD
  ALTER TABLE 테이블명
  ADD ( 컬럼명1 데이터타입1(크기), 컬럼명2 데이터타입2(크기),... )

temp 테이블에  숫자 8자리를 담을 salary 컬럼 추가
DESC  temp;

ALTER TABLE temp
ADD ( salary NUMBER(8) );

DESC  temp;

101번의 salary 를 3000으로 변경
SELECT  *
FROM    temp;

UPDATE  temp
SET     salary = 3000
WHERE   id = 101;

SELECT  *
FROM    temp;

2) 데이터 타입 크기 변경 --MODIFY
  ALTER TABLE 테이블명
  MODIFY ( 컬럼명1 데이터타입1(크기), 컬럼명2 데이터타입2(크기)... );

temp 테이블의 salary 컬럼의 크기를 숫자 10으로 변경
ALTER TABLE temp
MODIFY ( salary NUMBER(10) );

DESC temp;

3) 컬럼 삭제 --DROP COLUMN
  ALTER TABLE 테이블명
  DROP COLUM 컬럼명;

temp 테이블의 salary 컬럼을 삭제 한다.
ALTER TABLE temp
DROP COLUMN salary;

DESC temp;

4) 컬럼명 변경 --RENAME COLUMN A TO B
  ALTER TABLE 테이블명
  RENAME COLUMN 원래컬럼명 TO 새컬럼명

temp 테이블의 id 컬럼명을 temp_id 로 변경
ALTER TABLE temp
RENAME COLUMN id TO temp_id;

DESC temp;

3. 테이블 삭제 --DROP
DROP TABLE 테이블명;

DROP TABLE temp;

테이블 복구
FLASHBACK TABLE temp TO BEFORE DROP;

4. 테이블의 데이터 행 삭제 -- TRUNCATE --조건절 사용 불가
  TRUNCATE TABLE 테이블명; --즉, 구조만 남기고 데이터행 모두 삭제
  
5. 테이블명 변경 -- RENANE
  RENAME 원래테이블명 TO 새테이블명;
  
RENAME  temp To test;

※ 정리
--------------------------------------------------------------------------------
1. 테이블 생성 --CREATE
  CREATE TABLE 테이블명 (
--￣￣￣￣￣￣  
    컬럼명1 데이터타입1(크기) 제약조건,
    컬럼명2 데이터타입2(크기) 제약조건
    ...
  );
  
2. 테이블 구조 변경 --ALTER
  1) 컬럼추가 --ADD
  ALTER TABLE 테이블명
  ADD (컬럼명1 데이터타입1(크기), 컬럼명2 데이터타입2(크기), ...);
--￣￣  
  
  2) 데이터타입이나 크기 변경 --MODIFY
  ALTER TABLE 테이블명
  MODIFY (컬럼명1  데이터타입1(크기), 컬럼명2 데이터타입2(크기), ...);
--￣￣￣  

  3) 컬럼 삭제 --DROP COLUMN
  ALTER TABLE 테이블명
  DROP COLUMN 컬럼명
--￣￣￣￣￣￣

  4) 컬럼명 변경 --RENAME COLUMN
  ALTER TABLE 테이블명
  RENAME COLUMN 원래컬럼명 TO 새컬럼명;
--￣￣￣￣￣￣￣           ￣

3. 데이터 행 삭제 --TRUNCATE - 조건절 사용 불가, 구조만 남기고 데이터행 삭제
  TRUNCATE  TABLE 테이블명; 
--￣￣￣￣￣￣￣￣

4. 테이블 삭제 --DROP
  DROP TABLE 테이블명 (purge) - purge : 휴지통 거치지 않고 영구 삭제
--￣￣￣￣￣  

5. 테이블명 변경 --RENAME
  RENAME  원래테이블명 TO 새테이블명
--￣￣￣               ￣
--------------------------------------------------------------------------------








