※ 조건문 : DECODE, CASE ~ END WHEN THEN ELSE

1.1  조건문에 해당하는 ㄴ함수 : DECODE
대상표현과 비교데이터 표현의 데이터유형은 일치해야 함(문자는 문자로 비교, 숫자는 숫자로 비교)
  : DECODE(대상표현, A , 1, B, 2, 3) 컬럼값이 A이면 1, B이면 2, 그것도 아니면 3
  : DECODE(대상표현, 비교데이터표현1, 반환데이터1,
                     비교데이터표현2, 반환데이터2,
                     비교데이터표현3, 반환데이터3,
                     기본반환데이터) ALIAS 명

사번, 성, 부서코드, 급여, 보너스 조회
보너스는 
부서코드가  10이면 급여의 10%,
            20이면 급여의 20%,
            30이면 급여의 30%,
            나머지는 급여의 5%
            
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY, 
       DECODE(DEPARTMENT_ID, 10, SALARY*0.1,
                             20, SALARY*0.2,
                             30, SALARY*0.3,
                             SALARY*0.05) 보너스
FROM EMPLOYEES;

1.2 조건문에 해당하는 함수 : CASE ~ END 
    CASE ~ END 함수는 DECODE 함수보다 더 큰 개념을 가진 표현식이다.
    
* DECODE함수는 동등비교 연산만 할수있으나 
  CASE ~ END  범위비교연산까지 가능하다
  범위비교  조건에 따라 데이터를 반환하는 경우에는 CASE ~ END 구문을 사용
  CASE ~ END 함수에서
  동등비교연산 : 범위비교연산과 표현이 다름, 범위비교시 대상 표현이 WHEN 절에 안에 있어야 함

동등비교연산
-------------------------------------------------------------------------
CASE 대상표현
  WHEN 비교데이터값1 THEN 반환데이터1 ---컴마없음
  WHEN 비교데이터값2 THEN 반환데이터2 ---컴마없음
  WHEN 비교데이터값3 THEN 반환데이터3 ---컴마없음
  
  ELSE 기본반환데이터
END   ALIAS 명
--------------------------------------------------------------------------

범위 비교연산
-------------------------------------------------------------------------
CASE 연산자 ☞ =, !=, <, <=, >, >= 등 사용
  WHEN 대상표현 연산자 비교데이터값1 THEN 반환데이터1 ---컴마없음
  WHEN 대상표현 연산자 비교데이터값2 THEN 반환데이터2 ---컴마없음
  WHEN 대상표현 연산자 비교데이터값3 THEN 반환데이터3 ---컴마없음
  
  ELSE 기본반환데이터
END   ALIAS 명

사번, 성, 부서코드, 급여, 보너스 조회
보너스는 
부서코드가  10이면 급여의 10%,
            20이면 급여의 20%,
            30이면 급여의 30%,
            나머지는 급여의 5%
            
--동등비교연산
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY,
       CASE DEPARTMENT_ID
          WHEN 10 THEN SALARY*0.1
          WHEN 20 THEN SALARY*0.2
          WHEN 30 THEN SALARY*0.3
          ELSE SALARY*0.05
       END BONUS
FROM EMPLOYEES;


--범위비교연산
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY,
       CASE 
          WHEN DEPARTMENT_ID = 10 THEN SALARY*0.1
          WHEN DEPARTMENT_ID = 20 THEN SALARY*0.2
          WHEN DEPARTMENT_ID = 30 THEN SALARY*0.3
          ELSE SALARY*0.05
       END BONUS
FROM EMPLOYEES;

보너스는 
부서코드  10 ~ 30 이면 급여의 10%,
          40 ~ 60 이면 급여의 20%,
          70 ~ 100 이면 급여의 30%,
          나머지는 급여의 5%
사번, 성, 부서코드, 급여, 보너스 조회

SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY,
       CASE 
          WHEN DEPARTMENT_ID BETWEEN 10 AND 30 THEN SALARY*0.1
          WHEN DEPARTMENT_ID BETWEEN 40 AND 60 THEN SALARY*0.2
          WHEN DEPARTMENT_ID BETWEEN 70 AND 100 THEN SALARY*0.3
          ELSE SALARY*0.05
       END BONUS
FROM EMPLOYEES;

※ 그룹함수 : 여러행으로부터 하나의 결과값을 반환
             전체 데이터를 그룹별로 구분하여 통계적인 결과를 구하기 위해서 사용
※ 그룹함수의 종류
1.COUNT         : 입력되는 데이터의 총갯수를 출력 
2.SUM           : 입력되는 데이터의 합계를 출력 
3.AVG           : 입력되는 데이터의 평균를 출력 
4.MAX           : 입력되는 데이터의 가장 큰값을 출력 
5.MIN           : 입력되는 데이터의 가장 작은값을 출력 

6.ROLLUP        : 입력되는 데이터의 소계 및 총계를 출력 
7.CUBE          : 입력되는 데이터의 소계 및 총계를 출력 (아래에 대시 데이터 출력)

8.RANK          : 주어진 컬럼값의 그룹에서 값의 순위를 계산한 후 순위를 출력  
                  ---- 1, 2, 2, 4 Group by 미사용
9.DENSE_RANK    : RANK외 비슷하지만 동일한 순위를 하나의 건수로 취급하므로 순위를 보여줌
                  ---- 1, 2, 2, 3 Group by 미사용
DISTINCT : SELECT 바로 다음에 쓰여 중복을 제거한 결과를 보여준다
뒤에 나오는 컬럼의 중복을 제거하고 조회하고자 하는 대표값만 표현하는 상태

SELECT DISTINCT EMPLOYEE_ID
FROM EMPLOYEES
WHERE EMPLOYEE_ID IS NOT NULL
ORDER BY 1;
