6. FROM 절에 사용하는 인라인 뷰 서브쿼리
SELECT 절의 결과를 FROM 절에서 하나의 테이블처럼 사용(테이블 대체 용도)
--* FROM 절에서 사용하는 인라인 뷰 서브쿼리에서 그룹함수는 반드시 ALIAS 지정해야 함
--* 메인쿼리에서 ALIAS 명을 컬럼명으로 사용하기 위해

01. 우리회사 사원들의 급여정보를 관리한 테이블이 있다
우리회사 최대급여, 최소급여, 평균급여를 조회 --24000	2100	6462
SELECT  MAX(salary) max_sal,
        MIN(salary) min_sal,
        ROUND(AVG(salary)) avg_sal
FROM    employees;

02. 우리회사 사원들의 급여정보를 관리한 테이블이 있다
사번, 성, 급여, 우리회사 최대급여, 최소급여, 평균급여를 조회
스칼라 서브쿼리
SELECT  e.employee_id, e.last_name, e.salary, 
        (SELECT MAX(salary) FROM employees) max_sal, 
        (SELECT MIN(salary) FROM employees) min_sal, 
        (SELECT ROUND(AVG(salary)) FROM employees) avg_sal
FROM    employees e;

인라인 뷰 서브쿼리
SELECT  e.employee_id, e.last_name, e.salary, m.max_sal, m.min_sal, m.avg_sal
FROM    employees e, ( SELECT  MAX(salary) max_sal,
                       MIN(salary) min_sal,
                       ROUND(AVG(salary)) avg_sal
                       FROM    employees ) m; --FROM 절에 사용하는 인라인 뷰 서브쿼리의
--                                              그룹함수는 반드시 ALIAS 지정해야 함

03. 사원이 받는 급여가 회사평균급여 이상 최대급여 이하에 해당하는 사원들의
사번, 성, 급여, 우리회사 최대급여, 우리회사 최소급여, 우리회사 평균급여 조회
스칼라 서브쿼리
SELECT  e.employee_id, e.last_name, e.salary, 
        ( SELECT MAX(salary) FROM employees ) max_sal,
        ( SELECT MIN(salary) FROM employees ) min_sal,
        ( SELECT ROUND(AVG(salary)) FROM employees ) avg_sal
FROM    employees e
WHERE   e.salary BETWEEN ( SELECT ROUND(AVG(salary)) FROM employees ) 
AND     ( SELECT MAX(salary) FROM employees );

인라인뷰 서브쿼리
SELECT  e.employee_id, e.last_name, e.salary, m.max_sal, m.min_sal, m.avg_sal
FROM    employees e, ( SELECT MAX(salary) max_sal, MIN(salary) min_sal, ROUND(AVG(salary)) avg_sal
                       FROM employees ) m
WHERE   e.salary BETWEEN m.avg_sal AND m.max_sal;

04. 각 부서별로 가장 많은 급여를 받는 사원들의
사번, 성, 부서코드, 급여
--다중컬럼 서브쿼리, 부서별 최대급여를 급여로 전달
SELECT  e.employee_id, e.last_name, e.department_id, e.salary
FROM    employees e
WHERE   (NVL(e.department_id,0), e.salary) IN ( SELECT NVL(department_id,0), MAX(salary)
                                                FROM   employees 
                                                GROUP BY department_id )
ORDER BY 3;

인라인뷰 서브쿼리
SELECT  e.employee_id, e.last_name, e.department_id, e.salary
FROM    employees e, ( SELECT department_id, MAX(salary) max_sal
                       FROM   employees 
                       GROUP BY department_id ) m
WHERE   NVL(e.department_id,0) = NVL(m.department_id,0)
AND     e.salary = m.max_sal
ORDER BY 3;

05. 우리회사 사원들의 급여 정보를 관리한 테이블이 있다.
사번, 성, 부서코드, 급여, 각 부서별 부서원수, 
부서최대급여, 부서최소급여, 부서평균급여를 인라인뷰 서브쿼리로 조회

각 부서별 부서원수, 부서최대급여, 부서최소급여, 부서평균급여
SELECT  department_id, COUNT(*) cnt, MAX(salary) max_sal, MIN(salary) min_sal, ROUND(AVG(salary)) avg_sal
FROM    employees 
GROUP BY department_id
ORDER BY 1;

인라인 뷰 서브쿼리
SELECT  e.employee_id, e.last_name, e.department_id, e.salary, m.cnt, m.max_sal, m.min_sal, m.avg_sal
FROM    employees e, ( SELECT  department_id, COUNT(*) cnt, MAX(salary) max_sal, MIN(salary) min_sal, ROUND(AVG(salary)) avg_sal
                       FROM    employees 
                       GROUP BY department_id ) m
WHERE   NVL(e.department_id,0) = NVL(m.department_id,0);

06. 부서별로 가장 많은 급여를 받는 사원의
사번, 성명, 부서코드, 급여, 업무코드 조회
다중컬럼 서브쿼리 --부서별 최대급여를 급여로 전달
SELECT  e.employee_id, e.first_name || ' ' || e.last_name name, e.department_id,
        e.salary, e.job_id
FROM    employees e
WHERE   (NVL(e.department_id,0), e.salary) IN ( SELECT NVL(department_id,0), MAX(salary) max_sal
                                                FROM   employees
                                                GROUP BY department_id )
ORDER BY 3;

인라인뷰 서브쿼리
SELECT  e.employee_id, e.first_name || ' ' || e.last_name name, e.department_id,
        e.salary, e.job_id
FROM    employees e, ( SELECT department_id, MAX(salary) max_sal
                       FROM   employees
                       GROUP BY department_id ) m
WHERE   e.department_id = m.department_id
AND     e.salary = m.max_sal
ORDER BY 3;

07. 각 부서별로 가장 최근에 입사한 사원들의
사번, 성, 부서코드, 가장 최근입사일자
다중컬럼 서브쿼리 --가장 최근에 입사한 날짜를 날짜로 반환
SELECT  e.employee_id, e.last_name, e.department_id, hire_date
FROM    employees e
WHERE   (NVL(department_id,0), hire_date) IN ( SELECT  NVL(department_id,0), MAX(hire_date) max_hire
                                               FROM    employees
                                               GROUP BY department_id )
ORDER BY 3;
인라인뷰 서브쿼리
SELECT  e.employee_id, e.last_name, e.department_id, hire_date
FROM    employees e, ( SELECT  department_id, MAX(hire_date) max_hire
                       FROM    employees
                       GROUP BY department_id ) m
WHERE   NVL(e.department_id,0) = NVL(m.department_id,0)
AND     e.hire_date = m.max_hire
ORDER BY 3;

7. 몇개의 데이터 행을 조회해보자
데이터 행을 조회 : ROWNUM - 테이블에 존재하지 않는 컬럼은 아니지만 사용할 수 있는 가짜 컬럼
SELECT 및 WHERE 절에서 사용
--* 쿼리문의 결과(조회 후 SELECT 절의 결과)로 나온 각행에 대한 순서값
--* 서브쿼리에서 먼저 정렬(ORDER BY) 후 메인쿼리에서 순번 매기기
--※ ROWNUM 과 인라인 뷰의 특성을 이용하여 페이징 처리 등의 작업을 수행

우리회사 사원들의
사번, 성, 급여 조회
SELECT  ROWNUM, employee_id, last_name, salary --조회한 순으로 ROWNUM 처리
FROM    employees;

우리회사 사원들에 대해 급여를 많이 받는 순으로 정렬하여
사번, 성, 급여 조회
SELECT  ROWNUM, employee_id, last_name, salary --2. 컬럼조회
FROM    employees     --1. 테이블 조회
ORDER BY salary DESC; --3. salary 로 내림차순

우리회사 사원들에 대해 사번 순으로 조회하여 10번까지
사번, 성, 급여 조회
SELECT  ROWNUM, employee_id, last_name, salary --3. 컬럼조회
FROM    employees     --1. 테이블 조회
WHERE   ROWNUM <= 10; --2. 10개 조회

우리회사 사원들에 대해 사번 순으로 조회하여 10번까지 급여 내림차순
SELECT  ROWNUM, employee_id, last_name, salary --3. 컬럼조회
FROM    employees     --1. 테이블 조회
WHERE   ROWNUM <= 10  --2. 10개 조회
ORDER BY salary DESC; --4. salary DESC

인라인뷰를 사용하여
급여 상위 10명에 대한
사번, 성, 급여 조회

SELECT  ROWNUM, e.*
FROM    ( SELECT  employee_id, last_name, salary
          FROM    employees
          ORDER BY salary DESC ) e
WHERE   ROWNUM <= 10;

인라인뷰를 사용하여
급여 하위 10명에 대한
사번, 성, 급여 조회

SELECT  ROWNUM, e.*
FROM    ( SELECT  employee_id, last_name, salary
          FROM    employees
          ORDER BY salary ASC ) e
WHERE   ROWNUM <= 10;

인라인뷰를 사용하여
입사일자 빠른 사원 10명에 대해
사번, 성, 입사일자 조회

SELECT  ROWNUM, e.*
FROM    ( SELECT  employee_id, last_name, hire_date
          FROM    employees 
          ORDER BY hire_date ASC ) e
WHERE   ROWNUM <= 10;














































