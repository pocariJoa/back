3. 문자데이터에 특정문자를 채워서 반환하는 함수
  : LPAD/RPAD(대상, 전체크기, 충전문자)
  : 3번째 파라미터는 생략가능 : 기본값 공백문자
SELECT LPAD('abc',5,'?') l1,
       LPAD('abc',5)     l2,
       RPAD('abc',5,'#') R1
FROM DUAL;

4. 문자데이터에서 특정문자를 제거하고 반환하는 함수
  : 제거할 문자한개만 지정가능 
  : 입력상자에서 사용자 실수로 공백을 입력시 제거
  : request.getParameter('userId').TRIM();
  TRIM([LEADING, TRAILING, BOTH] [제거문자한개] [FROM] 대상문자)
      제거할 위치 LEADING : 왼쪽, TRAILING: 오른쪽, BOTH: 양쪽, 생략시 BOTH
      제거할 문자 - 생략시 공백
      
SELECT '     ABAABABAAAAA'    T1,
TRIM('A' FROM 'ABAABABAAAAA') T2,
TRIM(LEADING 'A' FROM 'ABAABABAAAAA') T3,
TRIM(TRAILING 'A' FROM 'ABAABABAAAAA') T4,
TRIM(BOTH 'A' FROM 'ABAABABAAAAA') T5,
TRIM('     ABAABABAAAAA    ') T6
FROM DUAL;
--TRIM은 한문자만 제거 (한글자 아님)

5. 문자데이터에 특정문자를 제거하고 반환하는 함수
  : 제거할 문자를 여러개 지정 가능 : TRIM 함수와 차이점
  : LTRIM/RTRIM(대상문자, 제할 문자 나열)
  : 두번쨰 파라미터 생략시 기본값 공백문자
SELECT LTRIM('abcdcba', 'a') t1,
      LTRIM('abcdcba', 'ba') t2,
      rtrim('abcdcba', 'acb') t3,
      rtrim('abcdcba', 'adb') t4,
      rtrim('abcdcba', 'bc') t5
from dual;

6. 문자열에서 문자열의 일부를 반환(몇번째부터 몇글자)하는 함수
  : SUBSTR(대사, 시작위치, 몇글자)
  : 두번째 파라미터 : 음수지정가능<- 오른쪽부터
  : 세번째 파라미터 : 생략시 문자열의 끝까지 반환
SELECT SUBSTR('You are not alone', 5, 3) s1,
       SUBSTR('You are not alone', 5) s2,
       SUBSTR('You are not alone', -5, 3) s3
FROM DUAL;

7. 문자열에서 특정문자열이 위치한 시작위치를 반환하는 함수
  : INSTR(대상문자열, 찾는문자열, 문자열찾는위치, 몇번째꺼)
  : 두번쨰 파라미터 : 찾는문자열
  : 세번째 파라미터 : 문자열찾는위치(음수지정가능 -> 오른쪽에서 왼쪽방향으로 진행)
  : 네번째 파라미터 : 몇번째꺼, 생략시 첫번째꺼
select instr('Every sha-la-la-la-la','la',1,2) i1,
       instr('Every sha-la-la-la-la','la',12,2) i2,
       instr('Every sha-la-la-la-la','la',12,4) i3,
       instr('Every sha-la-la-la-la','la',12) i4,
       instr('Every sha-la-la-la-la','la',-3,2) i5,
       instr('Every sha-la-la-la-la','la',-10) i6
from dual;

본인의 이메일에서 아이디와 서비스제공자를 조회
select 'admin@hanmail.net' "나의 이메일",
        instr('admin@hanmail.net','@') dd,
        SUBSTR('admin@hanmail.net', 7) s1,
        SUBSTR('admin@hanmail.net', -7) s2
from dual;

jobs 테이블에서 업무코드, 업무제목,  직무, 직책 조회
직무, 직책은 업무코드에서 '_'를 기준으로 조회(직무_직책)
SELECT JOB_TITLE, SUBSTR(JOB_ID,1, instr(JOB_ID,'_')-1) 직무, SUBSTR(JOB_ID, instr(JOB_ID,'_')+1) 직책
      -- instr(JOB_ID,'_') dd
FROM JOBS;

8. 문자열에서 특정문자열을 찾아 다른 문자로 바꿔 변환하는 함수
단어를 통째로 변환
  : REPLACE(대상문자열, 찾는문자열, 대체될문자열)
  : 세번째 파라미터 : 생략시 NULL

SELECT REPLACE('You are not alone', 'You','We') r1,
       REPLACE('You are not alone', 'not') r2,
       REPLACE('You are not alone', 'You',NULL) r3
from dual;

9. 문자열에 있는 특정문자 전체를 다른 특정문자로 하나씩 1:1로 대응해서 바꿔주는 함수
  : TRANSLATE(대상문자열, 찾는물자열나열, 대체될문자열)
SELECT TRANSLATE ('You are not alone', 'You', 'We') t1
--                                      Y -> W
--                                      o -> e
--                                      u -> Null <-공백이아니라 아예 삭제
from dual;

3.3. 날짜 함수 : 송금, 출결, 회원가입의날짜 결제시간
1. 시스템의 현재날짜를 반환하는 함수 : SYSDATE
다른함수와는 달리 파라미터가 없어()를 사용하지 않음
SELECT SYSDATE TODAY
FROM DUAL;

날짜 +/- 숫자 : 날짜
날짜 - 날짜 : 숫자

SELECT SYSDATE + 1 tomorrow,
       SYSDATE - 1 yesterday
from dual;

SELECT SYSTIMESTAMP
FROM DUAL;

2. 특정날짜로부터 몇개월 전/후의 날짜를 반환하는 함수
:ADD_MONTHS(날짜, +/-개월)

오늘로부터 3개월 전/후 날짜 조회
SELECT ADD_MONTHS(SYSDATE, +3) "3개월 후",
       ADD_MONTHS(SYSDATE, -3) "3개월 전"
FROM DUAL;

3. 두 날짜 사이의 개월수의 차이를 반환하는 함수
  : MONTHS_BETWEEN(날짜1, 날짜2) 반드시 날짜1>날짜2
SELECT MONTHS_BETWEEN(SYSDATE, TO_DATE('2021-11-08')) "지난개월수",
       ROUND(MONTHS_BETWEEN(TO_DATE('2022-05-11'),SYSDATE ),1) "남은 개월수"
FROM DUAL;

4. 해당 날짜가 포함된 달의 마지막 일자를 반환하는 함수
  : LAST_DAY(날짜)
SELECT LAST_DAY(SYSDATE) l1, --이번달의 마지막 날짜
       LAST_DAY(ADD_MONTHS(SYSDATE, -3)) l2 ,--3개월전의 마지막 날짜
       LAST_DAY(ADD_MONTHS(SYSDATE, 3)) l23 --3개월전의 마지막 날짜
from dual;

5. 해당 날짜 이후의 날짜 중에서 요일로 명시된 요일에 해당되는 첫번째 날짜를 반환
  : NEXT_DAY(날짜, 요일)
  요일문자 : 일요일, 월요일, 일, 월, 숫자가능(1:일요일 ,2 : 월요일)
SELECT NEXT_DAY(SYSDATE,'일요일') N1,
       NEXT_DAY(SYSDATE,'일') N2,
       NEXT_DAY(SYSDATE, 1) N1
FROM DUAL;

3.4 형변환 함수
1. 숫자화 함수: TO_NUMBER(대상)  문자-> 숫자
SELECT '12345' N1,
      TO_NUMBER('12345') N2,
      12345 N3
FROM DUAL;

SELECT '20'+20 묵시적형변환
FROM DUAL;

2.문자화 함수: TO_CHAR(숫자나 날짜를 문자로 변환)
1) 숫자 -> 문자 : TO_CHAR(대상[,포맷형식] <-포맷형식은 생략가능)
포맷형식 : 정수는 지정한 형식보다 값이 길면 오류, 소수는 지정한 길이보다 길면 반올림
9:한자리 숫자, 무효숫자는 공백으로 채움(정수일때), 소수이하일때는 0으로 채움
  자릿수가부족하면 부족한 자리수만큼 #으로 표시
0:한자리 숫자 무효숫자는 무조건 0으로 채움
  자릿수가부족하면 부족한 자리수만큼 #으로 표시

SELECT 123456 T1,
TO_CHAR(123456) T2,
TO_CHAR(123456,'999999') T3,
TO_CHAR(123456,'9999999999') T4,
TO_CHAR(123456,'999') T5,
TO_CHAR(123456,'999,999,999') T6,
TO_CHAR(123456,'l999,999,999') T7
FROM DUAL;
--공백제거TRIM사용
SELECT TRIM(123456) T1,
TRIM(TO_CHAR(123456)) T2,
TRIM(TO_CHAR(123456,'999999')) T3,
TRIM(TO_CHAR(123456,'9999999999')) T4,
TRIM(TO_CHAR(123456,'999')) T5,
TRIM(TO_CHAR(123456,'999,999,999') )T6,
TRIM(TO_CHAR(123456,'l999,999,999')) T7
FROM DUAL;
-- 공백제거 : 포맷형식에 FM문구 삽입
SELECT 123456 T1,
TO_CHAR(123456) T2,
TO_CHAR(123456,'FM999999') T3,
TO_CHAR(123456,'FM9999999999') T4,
TO_CHAR(123456,'FM999') T5,
TO_CHAR(123456,'FM999,999,999') T6,
TO_CHAR(123456,'FMl999,999,999') T7
FROM DUAL;

2)날짜 -> 문자 : TO_CHAR(대상[, 포맷형식])
포맷형식 : 년-YEAR(년도를 영문으로 표시 : TWENTY TWENTY-ONE.
              YYYY,
              YY,
              RRRR,
              RR
           월-MONTH(달의 영문표기 모두 표시
              MON(3글자로 된 달의 이름)
              MM
           일-DAY(한글, 월요일, 요일의 영문표기 모두 표시)
              DY (한글, 월,  요일의 영문표기 약어 표시)
           시-HH, HH24
           분-MI
           초-SS
               
               
               
               
               
               
               