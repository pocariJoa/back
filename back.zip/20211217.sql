※ NVL : NULL 이 계산되었을 경우 결과값이 NULL 로 변경이 되어버림

SELECT  employee_id, salary, commission_pct
FROM    employees;

커미션 금액 1000미만인 사원의
사번, 이름, 급여, 커미션요율, 커미션 금액 조회
커미션 금액 = 급여 * 커미션요율
SELECT  employee_id, first_name, salary, commission_pct, 
        salary * commission_pct comm
FROM    employees
WHERE   salary * commission_pct < 1000;

★ 조회된 NULL 값을 치환하는 함수 : NVL(Null VaLue)함수, NVL2 함수
1. NVL(대상, NULL일때 반환표현)
--     ￣￣￣￣￣￣￣￣￣￣￣￣
     ★ 대상과 NULL일때 반환표현의 데이터 타입이 반드시 같아야 함
SELECT  employee_id, first_name, salary, NVL(commission_pct,0) comm1,
        salary * NVL(commission_pct,0) comm2
FROM    employees
WHERE   salary * NVL(commission_pct,0) < 1000;

사번, 성, 급여, 커미션요율, 커미션금액, 총급여 조회
총급여 = 급여 + 커미션금액
         급여 + NVL(커미션요율,0) * 급여
         급여 * (1 + NVL(커미션요율,0))
         
SELECT  employee_id, last_name, salary, NVL(commission_pct,0) 커미션요율,
        salary * NVL(commission_pct,0) 커미션금액,
        salary + salary * NVL(commission_pct,0) 총급여1,
        salary * (1 + NVL(commission_pct,0)) 총급여2
FROM    employees;

2. NVL2(대상, NULL이 아닐때, NULL일때)
--            ￣￣￣￣￣￣￣￣￣￣￣￣
NULL이 아닐때 반환표현과 NULL일때 반환표현의 데이터 타입이 반드시 일치해야 함
사번, 성, 급여, 커미션요율, 커미션금액, 총급여 조회
총급여 = 급여 + 커미션금액
         급여 + NVL(커미션요율,0) * 급여
         급여 * (1 + NVL(커미션요율,0))
SELECT  employee_id, last_name, salary, NVL2(commission_pct, commission_pct, 0) 커미션요율,
        salary * NVL2(commission_pct, commission_pct, 0) 커미션금액,
        salary + NVL2(commission_pct, commission_pct, 0) 총급여
FROM    employees;

3. 데이터값이 NULL 인경우 대체해서 반환 표현을 여러개 지정할 수 있는 형태의 함수
  : NULL이 아닌 첫번째 데이터를 반환하는 함수
  COALESCE(대체표현1, 대체표현2, 대체표현3, .....) ALIAS 명
    COALESCE : 합치다, 합체하다
--------------------------------------------------------------------------------
name    cellular            home              office
홍길동  010-1234-5678       062-111-1111
심청                        062-123-4567
전우치                      062-222-2222      062-234-5678  
--------------------------------------------------------------------------------

SELECT  name 이름, COALESCE(cellular, home, office) 연락처
FROM    dual;

결과
--------------------------------------------------------------------------------
이름      연락처          
홍길동    010-1234-5678 
심청      062-123-4567
전우치    062-222-2222
--------------------------------------------------------------------------------




































































