--TBLMEMBER : 주석   -- , Ctrl + shift + / , 모든 명령어는 세미콜론으로 종결
-- 명령이나 키워드는 대소문자 구분하지 않음, 대신 레코드들의 안의 데이터는 대소문자 구분
CREATE TABLE tblmember (
  num NUMBER PRIMARY KEY, --PRIMARY KEY는 UNIQUE, NOT NULL , 필드는 컴마로 구분
  name VARCHAR2(10),
  age NUMBER,
  addr VARCHAR2(50),
  tel VARCHAR2(20)
);

--tblmember 구조 보기
DESC tblmember;


--레코드 삽입
INSERT INTO tblmember(num,name,age,addr,tel)
VALUES(1,'홍길동',30,'광주시 서구 농성동','010-1111-2222');

INSERT INTO tblmember(num,name,age,addr,tel)
VALUES(2,'김길동',30,'광주시 서구 쌍촌동','010-2222-2222');

--전체 레코드 검색 SELECT
SELECT * FROM tblmember;


commit;

--DDL : 데이터ㅏ 정의어
DESC tblmember;

--tblmember 테이블에 phone 필드 추가
ALTER TABLE tblmember
ADD phone VARCHAR2(10);

--tblmember 테이블의 phone 필드 크기 변경
ALTER table tblmember
MODIFY (phone VARCHAR2(20));

--tblmember 테이블의 phone 필드 이름을 mobilephone으로 변경
ALTER table tblmember
RENAME COLUMN phone to mobilephone;

DESC tblmember;

--tblmember 테이블의 mobilephone 필드삭제
ALTER table tblmember
DROP COLUMN mobilephone;

--tblmember 테이블 삭제
drop table tblmember;

--tblmember 테이블 복구
FLASHBACK table tblmember TO BEFORE DROP;

--DML데이터 조작어
--임의의 레코드 삽입
INSERT INTO tblmember(num,name,age,addr,tel)
VALUES(3,'박길동',47,'광주 북구 용봉동','010-3333-3333');

INSERT INTO tblmember(num,name,age)
VALUES(4,'이순신',55);

--3번 레코드의 주소를 수정(서울시 강서구 화곡동으로)
UPDATE tblmember --반드시 조건절 지정
set addr = '서울시 강서구 화곡동'
where num =3;

SELECT* FROM tblmember;

--4번 레도크 삭제, 반드시 조건절 지정
DELETE FROM tblmember
WHERE num=4;

--번호, 이름 주소만 출력
SELECT num, name, addr
from tblmember;

--이름이 김길동인 회원을 출력
select *
from tblmember
WHERE name='김길동';

--이름이 김길동인 회ㅣ원의ㅣ 이름, 나이, 주소를 출력
SELECT name, age, addr
FROM tblmember
WHERE name = '김길동';

--나이가 40이상인 회원만 출력(비교연산자)
SELECT *
from tblmember
WHERE age>=40;

--나이가 40이상인 회원의 이름, 주소, 전화번호만 출력(비교연산자)
select name, addr, tel
from tblmember
where age >=40;

--나이가 30에서 50사이인 회원만 출력
SELECT*
from tblmember
WHERE age >=30 and age<=50;

select * 
from tblmember
WHERE age BETWEEN 30 and 50;

--주소에 특정 문자를 포함한 회원을 출력(LIKE)
--서구가 포함된 레코드 검색
SELECT * 
from tblmember
where addr like '%서구%'; --%서구$: 포함된
                          --서구% : 서구로 시작하는 
                          --%서구 : 서구로 끝나는
                          
--주소가 광으로 시작하는
SELECT *
from tblmember
WHERE addr like '광%';

--주소가 광으로 끝나는
SELECT *
from tblmember
WHERE addr like '%광';

--내장함수(count , sum , avg, max, min)
select *
from tblmember;

select count(name) --name필드의 갯수
from tblmember;
select COUNT(name) as nameCnt from tblmember; --AS ALIAS명
select COUNT(name) nameCnt from tblmember; --공백 ALIAS명

SELECT sum(age) sum_age --합계 함수
from tblmember;

SELECT avg(age) avg_age --평균 함수
from tblmember;

SELECT MAX(age) max_age --최대값 함수
from tblmember;

SELECT MIN(age) min_age --최소값 함수
from tblmember;

SELECT age + 2 "2년후 나이"
from tblmember;

--서구에 사는 사람들의 나이 합
select sum(age) 나이합
FROM tblmember
WHERE addr like '%서구%';

--num 값이 1, 3인 레코드
SELECT *
from tblmember
where num = 1 or num =3;

select *
from tblmember
WHERE num IN (1,3);

SELECT sysdate today--DBMS에 저장된 날짜 출력, 날짜는 '/'로 출력
FROM dual; --dual : 가짜 테이블

SELECT 5544*45
from dual;

select TO_char(sysdate, 'yyyy-mm-dd') today
from dual;

COMMIT;


--tblpanme 테이블 생성
CREATE TABLE tblpanme (
  code VARCHAR2(10) PRIMARY key,
  part VARCHAR2(20),
  price NUMBER
);

--레코드 입력
INSERT INTO tblpanme (code,part,price) VALUES('001','A영업부',3000);
insert into tblpanme VALUES('002','B영업부',6000);
insert into tblpanme VALUES('003','c영업부',2000);
insert into tblpanme VALUES('004','D영업부',3000);
insert into tblpanme VALUES('005','E영업부',4000);
insert into tblpanme VALUES('006','F영업부',7000);

SELECT* FROM tblpanme;

COMMIT;

SELECT part, SUM(price) sum_price
FROM tblpanme
GROUP by part
ORDER by part asc; -- order by : 정렬, 기본적으로 오름차순(asc), 내림차순(desc)

--부서명을 출력
select part
FROM tblpanme;


--중복제거 DISTINCT
SELECT DISTINCT part
FROM tblpanme;

--부서수 총 몇개인지를 검색
select count(DISTINCT part) 부서수
from tblpanme;

--부서별로 판매금액의 총합을 구하여 부서의 오름차순으로 정렬하여 출력
--단 , 부서가 2개이상 있는 부서만 대상으로 하시오 즉, a영업부 b영업부
SELECT part 부서, SUM(price) 급여합계
from tblpanme
-- where count(*) >=2 where절에서는 그룹함수 사용불가
GROUP by part
HAVING count(*) >=2
ORDER by 1;

UPDATE tblpanme set part = 'B영업부' where code = '006';
commit;






