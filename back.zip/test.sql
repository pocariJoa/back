SELECT * FROM student_info where no=2;
SELECT * FROM student_info;
SELECT * FROM TEST_MEMBER;
SELECT STUDENT_NO FROM TEST_MEMBER WHERE STUDENT_NO=2;
SELECT COUNT(*) FROM TEST_MEMBER WHERE USER_ID='kcj';
ROLLBACK;
commit;
--UPDATE [테이블] SET [열] = '변경할값' WHERE [조건]
--DELETE FROM [테이블] WHERE [조건]
--


INSERT INTO TEST_MEMBER(STUDENT_NO, USER_ID, USER_PW, USER_NICK)
VALUES (2,'kcj','1111','창재테스트');


UPDATE student_info SET name='창재' WHERE no = 2;

UPDATE student_info SET name='창재' WHERE no = 2;